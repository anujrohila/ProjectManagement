﻿Partial Class balance
End Class

Namespace balanceTableAdapters
    
    Partial Public Class balancetblTableAdapter
    End Class
End Namespace

Namespace PMS.balanceTableAdapters
    
    Partial Public Class balanceTableAdapter
    End Class
End Namespace
