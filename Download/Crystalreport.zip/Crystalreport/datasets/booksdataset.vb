﻿Partial Class _books
End Class

Namespace _booksTableAdapters

    Partial Public Class BooksTableAdapter
    End Class
End Namespace

Namespace _booksTableAdapters

    Partial Public Class BooksTableAdapter
    End Class
End Namespace
