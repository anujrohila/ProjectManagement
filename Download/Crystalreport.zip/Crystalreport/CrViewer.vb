﻿Imports CrystalDecisions.CrystalReports.Engine
Imports Microsoft.Reporting.WinForms
Imports CrystalDecisions.Shared
Imports CrystalDecisions.Web
Imports CrystalDecisions.ReportSource
Imports System.IO
Imports System.Net
Imports System.Net.Mail
Imports System
Imports System.Data.SqlClient

Public Class CrViewer
    Dim ds As New _books
    Dim da As SqlDataAdapter
    Dim sqlQRY As String = ""
    Dim cryrpts As New RptLedgerbook
    Sub viewreports(ByVal KK As String)

        Select Case m_rpts
            Case "Cash", "Bank"
                ds = New _books
                da = New SqlDataAdapter(sqlQRY, Cur_Conn_App)
                da.Fill(ds, "cashbook")

                Dim cryrpt As New Rptcashbook
                cryrpt.SetDataSource(ds.Tables("cashbook"))
                cryrpt.Refresh()
                cryrpt.SetParameterValue("supid", KK)
                cryrpt.SetParameterValue("compname", UCase(Cur_Company))
                cryrpt.SetParameterValue("sitename", "( " & cur_site & " )")
                cryrpt.SetParameterValue("OpBalance", Balances.LedgerBalance(cmb1.SelectedValue, Cur_Conn_App, Book_Start))
                Select Case m_rpts
                    Case "Cash"
                        cryrpt.SetParameterValue("rptname", cmb1.Text & "  (A/C Start From  " & Book_Start & " )")
                    Case "Bank"
                        cryrpt.SetParameterValue("rptname", cmb1.Text & "  (A/C Start From  " & Book_Start & " )")
                End Select
                CrystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None
                CrystalReportViewer1.ReportSource = cryrpt

            Case "Ledger", "caps"
                ds = New _books
                da = New SqlDataAdapter(sqlQRY, Cur_Conn_App)
                da.Fill(ds, "cashbook")

                cryrpts.SetDataSource(ds.Tables("cashbook"))
                cryrpts.Refresh()
                cryrpts.SetParameterValue("supid", KK)
                cryrpts.SetParameterValue("compname", UCase(Cur_Company))
                cryrpts.SetParameterValue("sitename", "( " & cur_site & " )")
                cryrpts.SetParameterValue("OpBalance", Balances.LedgerBalance(cmb1.SelectedValue, Cur_Conn_App, Book_Start))
                cryrpts.SetParameterValue("rptname", "Ledger: " & cmb1.Text)
                CrystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None
                CrystalReportViewer1.ReportSource = cryrpts

            Case "Trial"

                Dim ds3 As New DataSet1
                da = New SqlDataAdapter(sqlQRY, Cur_Conn_App)
                da.Fill(ds3.Tables(0))

                Dim cryrpt As New rptGrouptrial
                cryrpt.SetDataSource(ds3.Tables(0))
                cryrpt.Refresh()
                cryrpt.SetParameterValue("Head", "TRIAL BALANCE AS ON: " & StatusDate)
                cryrpt.SetParameterValue("mcompany", UCase(Cur_Company) & "  ( " & cur_site & " )")
                CrystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None
                CrystalReportViewer1.ReportSource = cryrpt


            Case "pnf"
                Dim ds3 As New DataSet1
                da = New SqlDataAdapter(sqlQRY, Cur_Conn_App)
                da.Fill(ds3.Tables(0))

                Dim cryrpt As New rptpnf
                cryrpt.SetDataSource(ds3.Tables(0))
                cryrpt.Refresh()
                Dim kk2 As Integer = ds3.Tables(0).Rows.Count
                cryrpt.SetParameterValue("Head", "PROFIT AND LOSS")
                cryrpt.SetParameterValue("mcompany", UCase(Cur_Company) & "  ( " & cur_site & " )")
                CrystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None
                CrystalReportViewer1.ReportSource = cryrpt

            Case "bs"
                Dim ds3 As New DataSet3
                da = New SqlDataAdapter(sqlQRY, Cur_Conn_App)
                da.Fill(ds3.Tables(0))

                Dim cryrpt As New rptassets
                cryrpt.SetDataSource(ds3.Tables(0))
                cryrpt.Refresh()
                Dim kk2 As Integer = ds3.Tables(0).Rows.Count
                cryrpt.SetParameterValue("Head", "BALANCE SHEET")
                cryrpt.SetParameterValue("mcompany", UCase(Cur_Company) & "  ( " & cur_site & " )")
                CrystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None
                CrystalReportViewer1.ReportSource = cryrpt

            Case "TOTALMATERIAL", "MONTHMATERIAL", "DAYMATERIAL"

                Dim ds3 As New materials
                da = New SqlDataAdapter(sqlQRY, Cur_Conn_App)
                da.Fill(ds3.Tables(0))

                Dim cryrpt As New rptMaterialSite
                cryrpt.SetDataSource(ds3.Tables(0))
                cryrpt.Refresh()
                Dim kk2 As Integer = ds3.Tables(0).Rows.Count
                Select Case KK
                    Case "TOTALMATERIAL"
                        cryrpt.SetParameterValue("Head", "UP TO DATE MATERIAL AT SITE")
                        cryrpt.SetParameterValue("mcompany", UCase(Cur_Company) & "  ( " & cur_site & " )")
                        cryrpt.SetParameterValue("area", CDbl(TextBox1.Text))
                    Case "MONTHMATERIAL"
                        cryrpt.SetParameterValue("Head", "MONTHLY MATERIAL")
                        cryrpt.SetParameterValue("mcompany", UCase(Cur_Company) & "  ( " & cur_site & " )")
                        cryrpt.SetParameterValue("area", CDbl(TextBox1.Text))
                        TextBox1.Visible = False
                    Case "DAYMATERIAL"
                        cryrpt.SetParameterValue("Head", "WEEKLY MATERIAL")
                        cryrpt.SetParameterValue("mcompany", UCase(Cur_Company) & "  ( " & cur_site & " )")
                        cryrpt.SetParameterValue("area", CDbl(TextBox1.Text))
                        TextBox1.Visible = False
                End Select


                CrystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None
                CrystalReportViewer1.ReportSource = cryrpt


            Case "Groupbalance", "supplier"
                Dim GrCon As SqlConnection
                GrCon = New SqlClient.SqlConnection
                GrCon.ConnectionString = "Data Source=" & Serverip & ",1533;Network Library=DBMSSOCN;Connect Timeout=30;initial Catalog=" & KK & ";User ID=chandresh;" & "Password=chan2210"
                GrCon.Open()
                Dim ds4 As New Grpsupplier
                da = New SqlDataAdapter(sqlQRY, GrCon)
                da.Fill(ds4.Tables(0))
                Dim kk2 As Integer = ds4.Tables(0).Rows.Count

                Dim cryrpt As New rptGrouptrial
                cryrpt.SetDataSource(ds4.Tables(0))
                cryrpt.Refresh()
                cryrpt.SetParameterValue("Head", "GROUP BALANCE")
                cryrpt.SetParameterValue("mcompany", "")
                CrystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None
                CrystalReportViewer1.ReportSource = cryrpt

                GrCon.Close()


            Case "Groupoutcre", "Groupoutdre"
                Dim GrCon As SqlConnection
                GrCon = New SqlClient.SqlConnection
                GrCon.ConnectionString = "Data Source=" & Serverip & ",1533;Network Library=DBMSSOCN;Connect Timeout=30;initial Catalog=" & KK & ";User ID=chandresh;" & "Password=chan2210"
                GrCon.Open()
                Dim ds4 As New DataSet2
                da = New SqlDataAdapter(sqlQRY, GrCon)
                da.Fill(ds4.Tables(0))
                Dim kk2 As Integer = ds4.Tables(0).Rows.Count

                Dim cryrpt As New rptgroupout1
                cryrpt.SetDataSource(ds4.Tables(0))
                cryrpt.Refresh()
                CrystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None
                CrystalReportViewer1.ReportSource = cryrpt

                GrCon.Close()

            Case "GroupTrial"
                Dim ds2 As New DataSet1
                Dim GrCon As New SqlConnection
                GrCon.ConnectionString = "Data Source=" & Serverip & ",1533;Network Library=DBMSSOCN;Connect Timeout=30;initial Catalog=" & KK & ";User ID=chandresh;" & "Password=chan2210"
                GrCon.Open()
                da = New SqlDataAdapter(sqlQRY, GrCon)
                da.Fill(ds2.Tables(0))
                Dim kk2 As Integer = ds2.Tables(0).Rows.Count

                Dim cryrpt As New rptGrouptrial
                cryrpt.SetDataSource(ds2.Tables(0))
                cryrpt.Refresh()
                cryrpt.SetParameterValue("Head", "GROUP TRIAL BALANCE")
                cryrpt.SetParameterValue("mcompany", "")
                CrystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None
                CrystalReportViewer1.ReportSource = cryrpt

                GrCon.Close()
            Case "gbs"
                Dim ds3 As New balance
                Dim GrCon As New SqlConnection
                GrCon.ConnectionString = "Data Source=" & Serverip & ",1433;Network Library=DBMSSOCN;Connect Timeout=30;initial Catalog=" & KK & ";User ID=chandresh;" & "Password=chan2210"
                GrCon.Open()
                da = New SqlDataAdapter(sqlQRY, GrCon)
                da.Fill(ds3.Tables(0))

                Dim cryrpt As New rptassets
                cryrpt.SetDataSource(ds3.Tables(0))
                cryrpt.Refresh()
                Dim kk2 As Integer = ds3.Tables(0).Rows.Count
                cryrpt.SetParameterValue("Head", "GROUP BALANCE SHEET")
                cryrpt.SetParameterValue("mcompany", "")
                CrystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None
                CrystalReportViewer1.ReportSource = cryrpt

            Case "ALB"
                Dim ds3 As New DataSet4
                da = New SqlDataAdapter(sqlQRY, Cur_Conn_App)
                da.Fill(ds3.Tables(0))

                Dim cryrpt As New RPT_SUPPLIER
                cryrpt.SetDataSource(ds3.Tables(0))
                cryrpt.Refresh()
                Dim kk2 As Integer = ds3.Tables(0).Rows.Count
                cryrpt.SetParameterValue("Head", "ALL LEDGER BALANCE")
                cryrpt.SetParameterValue("mcompany", "")
                CrystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None
                CrystalReportViewer1.ReportSource = cryrpt

        End Select

    End Sub

    Private Sub cmb1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles cmb1.KeyDown
        If e.KeyCode = Keys.Return Then
            Select Case m_rpts
                Case "Cash"

                    sqlQRY = "SELECT Supplier.NAMEis ,supplier.sup_id as sup_id, Supplier_1.Nameis AS NAMEiS2,supplier_1.sup_id as sup_id2, Mat_Accounttwo.* FROM (Mat_AccountTwo INNER JOIN Supplier ON Mat_AccountTwo.From_Account = Supplier.Sup_id) INNER JOIN Supplier AS Supplier_1 ON Mat_AccountTwo.To_Account = Supplier_1.sup_id where (MAT_ACCOUNTTWO.from_ACCOUNT= '" & cmb1.SelectedValue & "' OR MAT_ACCOUNTTWO.TO_ACCOUNT= '" & cmb1.SelectedValue & "') and (mode_pay_rec='CASH' OR MODE_PAY_REC='CONTRA') and mat_accounttwo.ddate >='" & Book_Start & "' order by ddate"
                    viewreports(cmb1.SelectedValue)
                Case "Bank"
                    sqlQRY = "SELECT Supplier.NAMEis ,supplier.sup_id as sup_id, Supplier_1.Nameis AS NAMEiS2,supplier_1.sup_id as sup_id2, Mat_Accounttwo.* FROM (Mat_AccountTwo INNER JOIN Supplier ON Mat_AccountTwo.From_Account = Supplier.Sup_id) INNER JOIN Supplier AS Supplier_1 ON Mat_AccountTwo.To_Account = Supplier_1.sup_id where (MAT_ACCOUNTTWO.from_ACCOUNT= '" & cmb1.SelectedValue & "' OR MAT_ACCOUNTTWO.TO_ACCOUNT= '" & cmb1.SelectedValue & "') and (mode_pay_rec='BANK' OR MODE_PAY_REC='CONTRA') and mat_accounttwo.ddate >='" & Book_Start & "' order by ddate"
                    viewreports(cmb1.SelectedValue)

                Case "Ledger"
                    sqlQRY = "SELECT Supplier.NAMEis ,supplier.sup_id as sup_id, Supplier_1.Nameis AS NAMEiS2,supplier_1.sup_id as sup_id2, Mat_Accounttwo.* FROM (Mat_AccountTwo INNER JOIN Supplier ON Mat_AccountTwo.From_Account = Supplier.Sup_id) INNER JOIN Supplier AS Supplier_1 ON Mat_AccountTwo.To_Account = Supplier_1.sup_id where (MAT_ACCOUNTTWO.from_ACCOUNT= '" & cmb1.SelectedValue & "' OR MAT_ACCOUNTTWO.TO_ACCOUNT= '" & cmb1.SelectedValue & "')  and mat_accounttwo.ddate >='" & Book_Start & "' order by ddate"
                    viewreports(cmb1.SelectedValue)
                Case "caps"
                    sqlQRY = "SELECT Supplier.NAMEis ,supplier.sup_id as sup_id, Supplier_1.Nameis AS NAMEiS2,supplier_1.sup_id as sup_id2, Mat_Accounttwo.* FROM (Mat_AccountTwo INNER JOIN Supplier ON Mat_AccountTwo.From_Account = Supplier.Sup_id) INNER JOIN Supplier AS Supplier_1 ON Mat_AccountTwo.To_Account = Supplier_1.sup_id where (MAT_ACCOUNTTWO.from_ACCOUNT= '" & cmb1.SelectedValue & "' OR MAT_ACCOUNTTWO.TO_ACCOUNT= '" & cmb1.SelectedValue & "')  order by ddate"
                    viewreports(cmb1.SelectedValue)
            End Select

        End If
    End Sub
    Private Sub CalculatePnf()
        Dim ds2 As New DataSet
        Dim sql As String = "select sum(supplier.creditammount) as PNF  from supplier inner join groupbysupplier on supplier.groupid=groupbysupplier.grpidsupplier where groupbysupplier.childof=32 or groupbysupplier.childof=33"
        Dim da As New SqlDataAdapter(sql, Cur_Conn_App)
        da.Fill(ds2, "tblpnf")
        ' ADDPnfJV(ds2.Tables("tblpnf").Rows(0).Item("pnf"))
    End Sub
    Private Sub ADDPnfJV(ByVal PNF As Double)
        Dim mycommand As SqlClient.SqlCommand
        Dim ds2 As New DataSet
        ' Dim ent As String
        ' Dim vrno As String
        Dim modes As String = "PNFJV"
        Dim SDISP As String
        Dim SHANDGROUP = "R"
        Dim mycommand2 As SqlClient.SqlCommand
A:
        Dim SQL As String = "SELECT SUP_ID FROM SUPPLIER WHERE GROUPID=44"
        Dim da As New SqlDataAdapter(SQL, Cur_Conn_App)
        da.Fill(ds2, "TBLPL")
        If ds2.Tables("tblpl").Rows.Count = 1 Then
            ' mycommand = New SqlCommand("delete from mat_accounttwo where to_account='" & ds2.Tables("tblpl").Rows(0).Item("sup_id").ToString & "' OR FROM_account='" & ds2.Tables("tblpl").Rows(0).Item("sup_id").ToString & "'", Pcnn)
            mycommand.ExecuteNonQuery()

            If PNF > 0 Then
C:
                Dim STO_ACCOUNT As String = Trim(ds2.Tables("TBLPl").Rows(0).Item("sup_id").ToString)
                Dim RECPAY As String = "RECEIPT"
                SQL = "SELECT SUP_ID,SHARE FROM SUPPLIER WHERE GROUPID=40"
                Dim da2 As New SqlDataAdapter(SQL, Cur_Conn_App)
                da2.Fill(ds2, "TBLCAP")
                If ds2.Tables("TBLCAP").Rows.Count > 0 Then
                    For Each drow In ds2.Tables("tblcap").Rows
                        ''ent = cn1.NewId
                        ''  vrno = cn1.VrNos
                        Dim SAMMOUNT As Double = PNF * CDbl((drow.Item("SHARE"))) / 100
                        Dim SFROM_ACCOUNT As String = Trim(drow.Item("SUP_ID").ToString)
                        SDISP = "HAVALO FROM PROFIT AND LOSS( NET PROFIT " + "  " & drow.Item("SHARE").ToString & " %) "
                        '  mycommand = New SqlCommand("insert into mat_accounttwo ([vrno],[ent_no],[ammount],[to_account],[from_account],[rec_pay],[mode_pay_rec],[ddate],[disp],[setviewone],[freezed],[isentryonly],[hide],[curdate],[chqno],[chqdrawn],[userss],[hand_group],[guidac]) values ('" & vrno & "','" & ent & "','" & SAMMOUNT & "','" & Trim(STO_ACCOUNT) & "','" & Trim(SFROM_ACCOUNT) & "','" & RECPAY & "','" & modes & "','" & Format(Date.Now, "MM-dd-yyyy") & "','" & SDISP & "','B',0,0,0,'" & Date.Now & "','x','x','" & m_user & "','R','x')", Pcnn)
                        mycommand.ExecuteNonQuery()
                    Next
                Else
                    Dim RES1 As Integer = MsgBox("NO CAPITAL AC , DO YOU WANT TO CREATE?", vbYesNo)
                    If RES1 = 6 Then
                        '  Dim F As New EditLedger
                        ' F.Button3.Enabled = False
                        '  F.Button4.Enabled = False
                        ''  F.Panel2.Visible = True
                        ''  F.Panel3.Visible = False
                        ' F.Panel2.Dock = DockStyle.Fill
                        '  F.ShowDialog()
                        '  F.Location = New Point(15, 80)
                        GoTo C
                    Else
                        Exit Sub
                    End If
                End If
            Else
B:
                Dim SFROM_ACCOUNT As String = Trim(ds2.Tables("TBLPl").Rows(0).Item("sup_id").ToString)
                Dim RECPAY As String = "PAYMENT"
                SQL = "SELECT SUP_ID,SHARE FROM SUPPLIER WHERE GROUPID=40"
                ' Dim da2 As New SqlDataAdapter(SQL, Pcnn)
                '  da2.Fill(ds2, "TBLCAP")
                If ds2.Tables("TBLCAP").Rows.Count > 0 Then
                    For Each drow In ds2.Tables("tblcap").Rows
                        ''ent = cn1.NewId
                        ''vrno = cn1.VrNos
                        Dim SAMMOUNT As Double = -1 * PNF * (drow.Item("SHARE").ToString) / 100
                        Dim STO_ACCOUNT As String = Trim(drow.Item("SUP_ID").ToString)
                        SDISP = "HAVALO FROM PROFIT AND LOSS( NET LOSS " + "  " & drow.Item("SHARE").ToString & " %) "
                        '  mycommand = New SqlCommand("insert into mat_accounttwo ([vrno],[ent_no],[ammount],[to_account],[from_account],[rec_pay],[mode_pay_rec],[ddate],[disp],[setviewone],[freezed],[isentryonly],[hide],[curdate],[chqno],[chqdrawn],[userss],[hand_group],[guidac]) values ('" & vrno & "','" & ent & "','" & SAMMOUNT & "','" & Trim(STO_ACCOUNT) & "','" & Trim(SFROM_ACCOUNT) & "','" & RECPAY & "','" & modes & "','" & Format(Date.Now, "MM-dd-yyyy") & "','" & SDISP & "','B',0,0,0,'" & Date.Now & "','x','x','" & m_user & "','R','x')", Pcnn)
                        mycommand.ExecuteNonQuery()
                    Next
                Else
                    Dim RES1 As Integer = MsgBox("NO CAPITAL AC , DO YOU WANT TO CREATE?", vbYesNo)
                    If RES1 = 6 Then
                        '   Dim F As New EditLedger
                        ' F.Button3.Enabled = False
                        ' F.Button4.Enabled = False
                        ' F.Panel2.Visible = True
                        ' F.Panel3.Visible = False
                        ' F.Panel2.Dock = DockStyle.Fill
                        '   F.ShowDialog()
                        '  F.Location = New Point(15, 80)
                        GoTo B
                    Else
                        Exit Sub
                    End If
                End If

            End If

        ElseIf ds2.Tables("tblpl").Rows.Count > 1 Then
            MsgBox("THERE IS MORE THEN ONE  PROFIT AND LOSS AC PLEASE REMOVE IT")
            Exit Sub
        ElseIf ds2.Tables("tblpl").Rows.Count = 0 Then
            Dim RES As Integer = MsgBox("NO PROFIT AND LOSS A/C DO YOU WANT TO CREATE?", vbYesNo)
            If RES = 6 Then
                'mycommand2 = New SqlCommand("insert into supplier([nameis],[groupid],[alias],[share],[addis],[city],[sup_ph],[opbalance],[sup_id],[userss],[autoupdate]) values ('" & UCase("PROFIT AND LOSS") & "','44','PNF',0,'X','X',1234,0,'" & cn1.NewId & "','" & m_user & "', 0  )", Pcnn)
                mycommand2.ExecuteNonQuery()
                GoTo A
            Else
                Exit Sub
            End If
        End If

    End Sub


    Private Sub CrViewer_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim dd As New FillControl
        Select Case m_rpts
            Case "Cash"
                dd.FillSupplier("CASH", cmb1, Cur_Conn_App, Cur_Permit)
                cmb1.Focus()
            Case "Bank"
                dd.FillSupplier("BANK", cmb1, Cur_Conn_App, Cur_Permit)
                cmb1.Focus()
            Case "Ledger"
                dd.FillSupplier("NOTCBSP", cmb1, Cur_Conn_App, Cur_Permit)
                cmb1.Focus()
                Button1.Visible = True
                'TextBox1.Visible = True
                ComboBox1.Visible = True
            Case "caps"
                dd.FillSupplier("CAP", cmb1, Cur_Conn_App, Cur_Permit)
                cmb1.Focus()
            Case "Trial"
                cmb1.Visible = False
                sqlQRY = "SELECT        Supplier.Sup_id, Supplier.NameiS, Supplier.AddiS, Supplier.creditammount, Supplier.GroupId, GroupBySupplier.GrpIdSupplier, " & _
                "GroupBySupplier.GroupSupplierName, GroupBySupplier.childOf, GroupBySupplier.Display, GroupBySupplier.ClosingBalance " & _
                "FROM            Supplier INNER JOIN " & _
                         "GroupBySupplier ON Supplier.GroupId = GroupBySupplier.GrpIdSupplier"

                viewreports("zz")
            Case "Groupbalance"
                cmb1.Visible = False
                sqlQRY = "SELECT        Supplier.CompName, Supplier.Addis, Supplier.creditammount, Supplier.Sup_Ph, Supplier.NameiS, Supplier.Sup_id, GroupBySupplier.GroupSupplierName " & _
"FROM  Supplier INNER JOIN " & _
                         "GroupBySupplier ON Supplier.GroupId = GroupBySupplier.GrpIdSupplier where (supplier.groupid=2 or supplier.groupid=6)"


                viewreports(CurGroupName)
            Case "supplier"
                cmb1.Visible = False
                sqlQRY = "select groupbysupplier.*,supplier.* from supplier inner join groupbysupplier on supplier.groupid=groupbysupplier.grpidsupplier where (supplier.groupid=27) and (supplier.creditammount not between -5000 and 5000) order by supplier.SUP_PH "
                viewreports(CurGroupName)
            Case "ALB"
                cmb1.Visible = False
                sqlQRY = "SELECT  Supplier.NameiS, Supplier.creditammount, GroupBySupplier.GroupSupplierName FROM Supplier INNER JOIN GroupBySupplier ON Supplier.GroupId = GroupBySupplier.GrpIdSupplier"
                viewreports(CurGroupName)
            Case "GroupTrial"
                cmb1.Visible = False

                sqlQRY = "SELECT        Supplier.Sup_id, Supplier.NameiS, Supplier.AddiS, Supplier.creditammount, Supplier.GroupId, GroupBySupplier.GrpIdSupplier, " & _
                "GroupBySupplier.GroupSupplierName, GroupBySupplier.childOf, GroupBySupplier.Display, GroupBySupplier.ClosingBalance " & _
                "FROM            Supplier INNER JOIN " & _
                         "GroupBySupplier ON Supplier.GroupId = GroupBySupplier.GrpIdSupplier"
                viewreports(CurGroupName)
            Case "pnf"
                cmb1.Visible = False
                CalculatePnf()
                sqlQRY = "select supplier.* ,groupbysupplier.* from supplier inner join groupbysupplier on supplier.groupid=groupbysupplier.grpidsupplier where groupbysupplier.childof=32 or groupbysupplier.childof=33 order by supplier.groupid "
                viewreports(CurGroupName)

            Case "TOTALMATERIAL"
                cmb1.Visible = False
                TextBox1.Visible = True
                TextBox1.Text = "1"
                sqlQRY = "SELECT Material.Mat_Name, Material.Mat_Unit,material.groupid, SUM(QtyMaterial.Qty) AS Sqty, SUM(QtyMaterial.Ammount) AS Sammount,SUM(QtyMaterial.Ammount)/SUM(QtyMaterial.Qty) as rate FROM Material INNER JOIN QtyMaterial ON Material.Mat_id = QtyMaterial.Mat_id GROUP BY Material.Mat_id, Material.Mat_Name, Material.Mat_Unit,material.groupid order by material.groupid"
                'sqlQRY = "SELECT Material.Mat_Name, Material.Mat_Unit, SUM(QtyMaterial.Qty) AS Sqty, SUM(QtyMaterial.Ammount) AS Sammount FROM Material INNER JOIN QtyMaterial ON Material.Mat_id = QtyMaterial.Mat_id GROUP BY Material.Mat_id, Material.Mat_Name, Material.Mat_Unit order by qtymaterial.groupid"
                viewreports("TOTALMATERIAL")
            Case "MONTHMATERIAL"
                cmb1.Visible = False
                TextBox1.Visible = True
                TextBox1.Text = "1"
                Dim date2 As Date = Format(Date.Now, "MM-dd-yyyy")
                Dim date1 As Date = DateAdd(DateInterval.Month, -1, date2)
                sqlQRY = "SELECT Material.Mat_Name, Material.Mat_Unit,material.groupid, SUM(QtyMaterial.Qty) AS Sqty, SUM(QtyMaterial.Ammount) AS Sammount,SUM(QtyMaterial.Ammount)/SUM(QtyMaterial.Qty) as rate FROM Material INNER JOIN QtyMaterial ON Material.Mat_id = QtyMaterial.Mat_id WHERE QTYMATERIAL.DDATE BETWEEN '" & date1 & "' AND '" & date2 & "' GROUP BY Material.Mat_id, Material.Mat_Name, Material.Mat_Unit,material.groupid order by material.groupid"
                'sqlQRY = "SELECT Material.Mat_Name, Material.Mat_Unit, SUM(QtyMaterial.Qty) AS Sqty, SUM(QtyMaterial.Ammount) AS Sammount FROM Material INNER JOIN QtyMaterial ON Material.Mat_id = QtyMaterial.Mat_id GROUP BY Material.Mat_id, Material.Mat_Name, Material.Mat_Unit order by qtymaterial.groupid"
                viewreports("MONTHMATERIAL")
            Case "DAYMATERIAL"
                cmb1.Visible = False
                TextBox1.Visible = True
                TextBox1.Text = "1"
                Dim date2 As Date = Format(Date.Now, "MM-dd-yyyy")
                Dim date1 As Date = DateAdd(DateInterval.Day, -7, date2)
                sqlQRY = "SELECT Material.Mat_Name, Material.Mat_Unit,material.groupid, SUM(QtyMaterial.Qty) AS Sqty, SUM(QtyMaterial.Ammount) AS Sammount,SUM(QtyMaterial.Ammount)/SUM(QtyMaterial.Qty) as rate FROM Material INNER JOIN QtyMaterial ON Material.Mat_id = QtyMaterial.Mat_id WHERE QTYMATERIAL.DDATE BETWEEN '" & date1 & "' AND '" & date2 & "' GROUP BY Material.Mat_id, Material.Mat_Name, Material.Mat_Unit,material.groupid order by material.groupid"
                'sqlQRY = "SELECT Material.Mat_Name, Material.Mat_Unit, SUM(QtyMaterial.Qty) AS Sqty, SUM(QtyMaterial.Ammount) AS Sammount FROM Material INNER JOIN QtyMaterial ON Material.Mat_id = QtyMaterial.Mat_id GROUP BY Material.Mat_id, Material.Mat_Name, Material.Mat_Unit order by qtymaterial.groupid"
                viewreports("DAYMATERIAL")
            Case "bs"
                cmb1.Visible = False

                sqlQRY = "SELECT GroupBySupplier_1.childOf, GroupBySupplier_1.GroupSupplierName AS [group], GroupBySupplier.GroupSupplierName AS childs, Supplier.NameiS,SUM(Supplier.creditammount) AS sumgr FROM   GroupBySupplier INNER JOIN Supplier ON GroupBySupplier.GrpIdSupplier = Supplier.GroupId INNER JOIN GroupBySupplier AS GroupBySupplier_1 ON GroupBySupplier.childOf = GroupBySupplier_1.GrpIdSupplier WHERE GroupBySupplier_1.childOf in (30,31) GROUP BY Supplier.NameiS, GroupBySupplier.GroupSupplierName, GroupBySupplier_1.childOf, GroupBySupplier_1.GroupSupplierName order by GroupBySupplier_1.childOf"

                viewreports(CurGroupName)
            Case "gbs"
                cmb1.Visible = False

                sqlQRY = "SELECT        GroupBySupplier_1.GroupSupplierName AS [group], GroupBySupplier.GroupSupplierName AS childs, SUM(Supplier.creditammount) AS sumgr," & _
                            " GroupBySupplier_1.childOf, Supplier.NameiS " & _
                            "FROM            GroupBySupplier INNER JOIN " & _
                            "Supplier ON GroupBySupplier.GrpIdSupplier = Supplier.GroupId INNER JOIN " & _
                            "GroupBySupplier AS GroupBySupplier_1 ON GroupBySupplier.childOf = GroupBySupplier_1.GrpIdSupplier " & _
                            "WHERE        (GroupBySupplier_1.childOf IN (30, 31)) " & _
                            "GROUP BY GroupBySupplier.GroupSupplierName, GroupBySupplier.GrpIdSupplier, GroupBySupplier_1.childOf, GroupBySupplier_1.GroupSupplierName, " & _
                            "Supplier.creditammount, Supplier.NameiS order by childof"

                viewreports(CurGroupName)

            Case "Groupoutcre"
                cmb1.Visible = False

                sqlQRY = "SELECT        GroupBySupplier.GroupSupplierName, Supplier.Sup_id, Supplier.NameiS, Supplier.Sup_Ph, Supplier.creditammount, Supplier.Addis, Supplier.CompName " & _
"FROM            Supplier INNER JOIN " & _
                         "GroupBySupplier ON Supplier.GroupId = GroupBySupplier.GrpIdSupplier where supplier.groupid=27 and supplier.creditammount<>0"

                viewreports(CurGroupName)
            Case "Groupoutdre"
                cmb1.Visible = False

                sqlQRY = "SELECT        GroupBySupplier.GroupSupplierName, Supplier.Sup_id, Supplier.NameiS, Supplier.creditammount, DiffGroup.Alias_id, DiffGroup.SupName " & _
                           "FROM            DiffGroup INNER JOIN " & _
                            "Supplier ON DiffGroup.Sup_id = Supplier.Sup_id INNER JOIN " & _
                            "GroupBySupplier ON Supplier.GroupId = GroupBySupplier.GrpIdSupplier where supplier.groupid=26"

                viewreports(CurGroupName)
        End Select
        cmb1.Focus()

    End Sub

    Private Sub TextBox1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox1.KeyDown
        If e.KeyCode = Keys.Return And IsNumeric(TextBox1.Text) = True Then
            viewreports("TOTALMATERIAL")
        End If
    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If InStr(TextBox1.Text, "@") > 0 Then
            Dim sql As String = "update supplier set adding='" & TextBox1.Text & "' where sup_id='" & cmb1.SelectedValue & "'"
            Dim cmd As New SqlCommand(sql, Cur_Conn_App)
            cmd.ExecuteNonQuery()
            '  SendCrystalMail(cryrpts, TextBox1.Text, "Ledger of Your Account Till " & Date.Now.ToString("dd-MM-yyyy").ToString, "Kindly Check and Send To me Back For Conformation")

        End If
        ComboBox1.Visible = True
        TextBox1.Visible = False
    End Sub

    Private Sub ComboBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ComboBox1.KeyPress
        TextBox1.Visible = True
        ComboBox1.Visible = False
        TextBox1.Text = ComboBox1.Text
        TextBox1.Focus()
    End Sub

    Private Sub cmb1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb1.SelectedIndexChanged

        Select Case m_rpts
            Case "Cash"
                sqlQRY = "SELECT Supplier.NAMEis ,supplier.sup_id as sup_id, Supplier_1.Nameis AS NAMEiS2,supplier_1.sup_id as sup_id2, Mat_Accounttwo.* FROM (Mat_AccountTwo INNER JOIN Supplier ON Mat_AccountTwo.From_Account = Supplier.Sup_id) INNER JOIN Supplier AS Supplier_1 ON Mat_AccountTwo.To_Account = Supplier_1.sup_id where (MAT_ACCOUNTTWO.from_ACCOUNT= '" & cmb1.SelectedValue & "' OR MAT_ACCOUNTTWO.TO_ACCOUNT= '" & cmb1.SelectedValue & "') and (mode_pay_rec='CASH' OR MODE_PAY_REC='CONTRA') and mat_accounttwo.ddate >='" & Book_Start & "' order by ddate"
                viewreports(cmb1.SelectedValue)
            Case "Bank"
                sqlQRY = "SELECT Supplier.NAMEis ,supplier.sup_id as sup_id, Supplier_1.Nameis AS NAMEiS2,supplier_1.sup_id as sup_id2, Mat_Accounttwo.* FROM (Mat_AccountTwo INNER JOIN Supplier ON Mat_AccountTwo.From_Account = Supplier.Sup_id) INNER JOIN Supplier AS Supplier_1 ON Mat_AccountTwo.To_Account = Supplier_1.sup_id where (MAT_ACCOUNTTWO.from_ACCOUNT= '" & cmb1.SelectedValue & "' OR MAT_ACCOUNTTWO.TO_ACCOUNT= '" & cmb1.SelectedValue & "') and (mode_pay_rec='BANK' OR MODE_PAY_REC='CONTRA') and mat_accounttwo.ddate >='" & Book_Start & "' order by ddate"
                viewreports(cmb1.SelectedValue)

            Case "Ledger"
                sqlQRY = "SELECT Supplier.NAMEis ,supplier.sup_id as sup_id, Supplier_1.Nameis AS NAMEiS2,supplier_1.sup_id as sup_id2, Mat_Accounttwo.* FROM (Mat_AccountTwo INNER JOIN Supplier ON Mat_AccountTwo.From_Account = Supplier.Sup_id) INNER JOIN Supplier AS Supplier_1 ON Mat_AccountTwo.To_Account = Supplier_1.sup_id where (MAT_ACCOUNTTWO.from_ACCOUNT= '" & cmb1.SelectedValue & "' OR MAT_ACCOUNTTWO.TO_ACCOUNT= '" & cmb1.SelectedValue & "')  and mat_accounttwo.ddate >='" & Book_Start & "' order by ddate"
                viewreports(cmb1.SelectedValue)
            Case "caps"
                sqlQRY = "SELECT Supplier.NAMEis ,supplier.sup_id as sup_id, Supplier_1.Nameis AS NAMEiS2,supplier_1.sup_id as sup_id2, Mat_Accounttwo.* FROM (Mat_AccountTwo INNER JOIN Supplier ON Mat_AccountTwo.From_Account = Supplier.Sup_id) INNER JOIN Supplier AS Supplier_1 ON Mat_AccountTwo.To_Account = Supplier_1.sup_id where (MAT_ACCOUNTTWO.from_ACCOUNT= '" & cmb1.SelectedValue & "' OR MAT_ACCOUNTTWO.TO_ACCOUNT= '" & cmb1.SelectedValue & "')  order by ddate"
                viewreports(cmb1.SelectedValue)
        End Select


    End Sub
End Class